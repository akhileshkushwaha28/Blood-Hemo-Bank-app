package com.dev334.blood.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.dev334.blood.R;

public class SplashScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}